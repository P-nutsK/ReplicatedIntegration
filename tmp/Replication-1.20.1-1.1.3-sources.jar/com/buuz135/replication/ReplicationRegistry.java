package com.buuz135.replication;

import com.buuz135.replication.api.IMatterType;
import com.buuz135.replication.api.MatterType;
import com.buuz135.replication.api.matter_fluid.IMatterHandler;
import com.buuz135.replication.recipe.MatterValueRecipe;
import com.hrznstudio.titanium.recipe.serializer.GenericSerializer;

import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;
import org.apache.commons.lang3.tuple.Pair;

import java.util.function.Supplier;

import static net.minecraftforge.common.capabilities.CapabilityManager.get;

public class ReplicationRegistry {

    public static final ResourceKey<Registry<IMatterType>> MATTER_TYPES_KEY = ResourceKey.createRegistryKey(new ResourceLocation(Replication.MOD_ID, "matter_types"));
    public static Supplier<IForgeRegistry<IMatterType>> MATTER_TYPES_REGISTRY = null;

    public static void init(){
        IEventBus eventBus = FMLJavaModLoadingContext.get().getModEventBus();
        CustomRecipeTypes.REC.register(eventBus);
        Serializers.SER.register(eventBus);
        Matter.IMATTER_TYPES.register(eventBus);
    }

    public static class Blocks{

        public static Pair<RegistryObject<Block>, RegistryObject<BlockEntityType<?>>> REPLICATOR = null;
        public static Pair<RegistryObject<Block>, RegistryObject<BlockEntityType<?>>> IDENTIFICATION_CHAMBER = null;
        public static Pair<RegistryObject<Block>, RegistryObject<BlockEntityType<?>>> DISINTEGRATOR = null;
        public static Pair<RegistryObject<Block>, RegistryObject<BlockEntityType<?>>> MATTER_NETWORK_PIPE = null;
        public static Pair<RegistryObject<Block>, RegistryObject<BlockEntityType<?>>> MATTER_TANK = null;
        public static Pair<RegistryObject<Block>, RegistryObject<BlockEntityType<?>>> REPLICATION_TERMINAL = null;
        public static Pair<RegistryObject<Block>, RegistryObject<BlockEntityType<?>>> CHIP_STORAGE = null;
        public static RegistryObject<Block> DEEPSLATE_REPLICA_ORE = null;
        public static RegistryObject<Block> REPLICA_BLOCK = null;
        public static RegistryObject<Block> RAW_REPLICA_BLOCK = null;

    }

    public static class Items{

        public static RegistryObject<Item> MEMORY_CHIP;
        public static RegistryObject<Item> MATTER_BLUEPRINT;
        public static RegistryObject<Item> RAW_REPLICA;
        public static RegistryObject<Item> REPLICA_INGOT;


    }

    public static class Sounds{

        public static RegistryObject<SoundEvent> TERMINAL_BUTTON = null;

    }

    public static class Matter{

        public static final DeferredRegister<IMatterType> IMATTER_TYPES = DeferredRegister.create(MATTER_TYPES_KEY, Replication.MOD_ID);

        public static final RegistryObject<IMatterType> EMPTY = IMATTER_TYPES.register("empty", () -> MatterType.EMPTY);
        public static final RegistryObject<IMatterType> METALLIC = IMATTER_TYPES.register("metallic", () -> MatterType.METALLIC);
        public static final RegistryObject<IMatterType> EARTH = IMATTER_TYPES.register("earth", () -> MatterType.EARTH);
        public static final RegistryObject<IMatterType> NETHER = IMATTER_TYPES.register("nether", () -> MatterType.NETHER);
        public static final RegistryObject<IMatterType> ORGANIC = IMATTER_TYPES.register("organic", () -> MatterType.ORGANIC);
        public static final RegistryObject<IMatterType> ENDER = IMATTER_TYPES.register("ender", () -> MatterType.ENDER);
        public static final RegistryObject<IMatterType> PRECIOUS = IMATTER_TYPES.register("precious", () -> MatterType.PRECIOUS);
        public static final RegistryObject<IMatterType> QUANTUM = IMATTER_TYPES.register("quantum", () -> MatterType.QUANTUM);
        public static final RegistryObject<IMatterType> LIVING = IMATTER_TYPES.register("living", () -> MatterType.LIVING);

    }

    public static class Colors{

        public static float[] GREEN_SPLIT = new float[]{23/255f,229/255f,23/255f};
        public static int GREEN = Mth.color(GREEN_SPLIT[0], GREEN_SPLIT[1], GREEN_SPLIT[2]);

    }

    public static class Capabilities{

        public static Capability<IMatterHandler> MATTER_HANDLER = get(new CapabilityToken<>(){});

    }

    public static class CustomRecipeTypes {

        public static final DeferredRegister<RecipeType<?>> REC = DeferredRegister.create(ForgeRegistries.RECIPE_TYPES.getRegistryKey(), Replication.MOD_ID);

        public static final RegistryObject<RecipeType<MatterValueRecipe>> MATTER_VALUE_RECIPE_TYPE = REC.register("matter_value", () -> RecipeType.simple(new ResourceLocation(Replication.MOD_ID, "matter_value")));
    }

    public static class Serializers{

        public static final DeferredRegister<RecipeSerializer<?>> SER = DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS.getRegistryKey(), Replication.MOD_ID);

        public static final RegistryObject<RecipeSerializer<?>> MATTER_VALUE_RECIPE_SERIALIZER = SER.register("matter_value", () -> new GenericSerializer(MatterValueRecipe.class, CustomRecipeTypes.MATTER_VALUE_RECIPE_TYPE ));

    }


}
