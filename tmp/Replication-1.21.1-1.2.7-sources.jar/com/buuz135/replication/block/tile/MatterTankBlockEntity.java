package com.buuz135.replication.block.tile;

import com.hrznstudio.titanium.block.BasicTileBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.NotNull;

import java.util.function.BooleanSupplier;

public class MatterTankBlockEntity extends BaseMatterTankBlockEntity<MatterTankBlockEntity> {

    public MatterTankBlockEntity(BasicTileBlock<MatterTankBlockEntity> base, BlockEntityType<?> blockEntityType, BlockPos pos, BlockState state, BooleanSupplier isCreative) {
        super(base, blockEntityType, pos, state, isCreative);
    }

    @Override
    public @NotNull MatterTankBlockEntity getSelf() {
        return this;
    }
}
